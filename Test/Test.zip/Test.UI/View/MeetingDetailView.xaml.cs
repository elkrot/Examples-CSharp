﻿using System.Windows.Controls;

namespace Test.UI.View
{
    /// <summary>
    /// Interaction logic for MeetiingView.xaml
    /// </summary>
    public partial class MeetingDetailView : UserControl
    {
        public MeetingDetailView()
        {
            InitializeComponent();
        }
    }
}
