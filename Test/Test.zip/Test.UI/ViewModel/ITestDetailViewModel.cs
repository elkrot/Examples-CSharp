﻿using System.Threading.Tasks;

namespace Test.UI.ViewModel
{


    public interface ITestDetailViewModel: IDetailViewModel
    {
        
    }
}