﻿namespace Test.UI.ViewModel
{
    public interface IMessageService
    {
    }
}