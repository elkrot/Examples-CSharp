﻿namespace Test.UI.ViewModel
{
    public interface IMeetingDetailViewModel : IDetailViewModel
    {
        
    }
}
